<div style="display: none;">
	<div class="box-modal popups article-template" id="tradeVideo">
		<div class="win-modal ">
			<div class="close js-close">
				<svg viewBox="0 0 9.63 9.58" xmlns="http://www.w3.org/2000/svg"><g fill="none" stroke="#b8b8b8" stroke-linecap="round" stroke-miterlimit="10" stroke-width=".75"><path d="m.38.38 8.73 8.73"/><path d="m9.26.38-8.84 8.83"/></g></svg>
			</div><!-- /.close -->
			
			<iframe width="1000" height="600" src="https://www.youtube.com/embed/KilZhQWMxEw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
		</div>
	</div>
</div>