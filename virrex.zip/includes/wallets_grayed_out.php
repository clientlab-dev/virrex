<div class="wrap">
    <div class="wallets-p wallets-p--transparent">
        <!-- <div class="row" id="row"> -->
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/steem.png" id="img" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">Steem</p>
                    <p class="wallets-p__short-title" >Steem</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/neo.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">Neo</p>
                    <p class="wallets-p__short-title">Neo</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/iota.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">Iota</p>
                    <p class="wallets-p__short-title">miota</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/lisk.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                <p class="wallets-p__title">Lisk</p>
                <p class="wallets-p__short-title">lsk</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/waves.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">Waves</p>
                    <p class="wallets-p__short-title">vavea</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/game_credits.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                        <p class="wallets-p__title">Game Credits</p>
                    <p class="wallets-p__short-title">Game Credits</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/cardano.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">cardano</p>
                    <p class="wallets-p__short-title" id="tooltip">cardano</p>
                </div>
            </div>

            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/bytecoin.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">Bytecoin</p>
                    <p class="wallets-p__short-title" id="tooltip">Bytecoin</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/tron.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">TRON</p>
                    <p class="wallets-p__short-title" id="tooltip">TRON</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                    <img src="assets/img/crypto_logos/eos.png" alt="">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title">EOS</p>
                    <p class="wallets-p__short-title" id="tooltip">EOS</p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title"></p>
                    <p class="wallets-p__short-title" id="tooltip"></p>
                </div>
            </div>
            <div class="wallets-p__col">
                <div class="wallets-p__img-block">
                </div>
                <div class="wallets-p__block" tabindex="0">
                    <p class="wallets-p__title"></p>
                    <p class="wallets-p__short-title" id="tooltip"></p>
                </div>
            </div>

    </div>
</div>